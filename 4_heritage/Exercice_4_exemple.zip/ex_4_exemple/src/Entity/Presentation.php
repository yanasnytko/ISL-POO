<?php
namespace ISL\Entity;

interface Presentation {
  public function profil();
}
