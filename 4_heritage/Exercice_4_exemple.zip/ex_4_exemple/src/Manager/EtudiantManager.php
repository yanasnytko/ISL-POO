<?php
namespace ISL\Manager;

use ISL\Entity\Etudiant;
use Faker\Factory;

class EtudiantManager extends EntityManager{

	public function create($etudiant){
	}

	public function read($id){

  }
	public function readAll(){

  }
	public function update($etudiant){

  }
	function delete($id){

  }
}
