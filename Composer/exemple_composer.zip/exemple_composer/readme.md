# README

## Creation du projet :
En ligne de commande dans un répertoire vide :

> composer init

Un assistant vous aidera a creer votre projet:
1. Definition du nom de votre projet : ici app/demo  => c'est le namespace de base de votre projet !!
2. Petite definition de votre projet
3. Auteur
4. Type (ici projet)
5. Ajout des dépendances (= librairies extérieurs dont vous avez besoin) 
	=> ajout de faker
	Source et Doc : 
		https://github.com/fzaninotto/Faker
	ou 	https://fakerphp.github.io/
	
6. ajout du path relatif à l'autoload (ici /app) (c'est le répertoire ou ce trouvera votre code source au sein de votre projet)

	

{
    "name": "app/demo",
    "description": "demo d'utilisation de composer et namespaces",
    "type": "project",
    "require": {
        "fzaninotto/faker": "^1.9"
    },
    "autoload": {
        "psr-4": {
            "App\\Demo\\": "app/"
        }
    },
    "authors": [
        {
            "name": "natacha braun",
            "email": "braun.natacha@gmail.com"
        }
    ]
}

## Ajout d'un index.php
Charger l'autoload de composer 

 > require ‘vendor/autoload.php’;
 

