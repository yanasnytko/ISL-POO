<?php
namespace App\Demo\Manager;
// utilisation de la librairie de Faker
use Faker\Factory;

class TestManager {
	private $faker;


	public function __construct(){
		$this->faker = Factory::create();
	}
	public function Manage(){
		$names = [];
		for ($i = 0; $i < 10; $i++) {
		  array_push($names,$this->faker->name);
		}
		return $names;
	}

}
