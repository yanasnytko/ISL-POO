<?php
namespace App\Demo;

class ClasseA {

	public function Hello(){
		return "Hello de classeA";
	}

}
