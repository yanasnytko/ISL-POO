<?php
require_once 'vendor/autoload.php';

use App\Demo\ClasseA;
use App\Demo\Manager\TestManager;

echo "\n";

echo (new ClasseA())->hello();

echo "\n";echo "\n";

$faker = Faker\Factory::create();

// generate data by accessing properties
echo $faker->name;

echo "\n";
echo "\n";

echo $faker->address;

echo "\n";
echo "\n";

echo $faker->text;

echo "\n";echo "\n";

$testManager = new TestManager();
foreach($testManager->Manage() as $name){
	echo $name . "\n";
}
